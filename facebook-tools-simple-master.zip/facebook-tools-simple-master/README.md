#Chức Năng:
- [Xác nhận (từ chối) lời mời kết bạn - Hủy kết bạn bằng Access Token](confirm-reject-and-remove-friends.html)
- [Block danh sách UID bằng Access Token](block-uid.html)
- [Gửi tin nhắn đến 1 ID nhất định bằng list Access Token](send-inbox-to-one-id.html)
- [Chia sẻ bài viết lên tường bạn bè đang online bằng Access Token](share-post-to-friends-online.html)
- [Lấy Cookies của tài khoản bằng Access Token](get-cookies-from-access-token.html)
- [Lấy Access Token full Quyền](get-session-for-app.html)
- [Xóa tài khoản quảng cáo rác (Chưa có phương thức thanh toán)](remove-adaccounts-no-payment.html)
- [Xóa album ảnh khỏi trang cá nhân](delete-albums.html)
